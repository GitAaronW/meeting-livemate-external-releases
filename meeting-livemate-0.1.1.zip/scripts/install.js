'use strict';
// Double-click install.command. This file is not run by tests.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

function programNode(root) {
  const folder = process.arch === 'arm64' ? 'node-v22.23.2-darwin-arm64' : 'node-v22.23.2-darwin-x64';
  const bundled = path.join(root, 'runtime', folder, 'bin', 'node');
  if (fs.existsSync(bundled)) return bundled;
  return process.execPath;
}
function install() {
  const src = path.resolve(__dirname, '..');
  const dataDir = path.join(os.homedir(), 'Library/Application Support/MeetingLiveMate');
  const dest = path.join(dataDir, 'program');
  const forbidden = ['/Tinghuitai/', '/TinghuitaiUS/', '/TinghuitaiAaron/'];
  const joined = path.resolve(dest) + path.sep;
  if (forbidden.some(part => joined.includes(part))) throw new Error('Refusing to install over the daily beta.');
  fs.mkdirSync(dest, { recursive: true });
  fs.cpSync(src, dest, {
    recursive: true,
    force: true,
    filter: (from) => {
      const rel = path.relative(src, from);
      if (!rel) return true;
      const top = rel.split(path.sep)[0];
      return !['data', '.git'].includes(top);
    },
  });
  if (!fs.existsSync(path.join(dest, 'node_modules', 'ws'))) {
    execFileSync('npm', ['install', '--omit=dev'], { cwd: dest, stdio: 'inherit' });
  }
  const startup = require(path.join(dest, 'app', 'startup.js'));
  const app = startup.create({ dataDir, port: 47921, root: dest, node: programNode(dest) });
  app.set(true);
  app.desktop();
  const domain = 'gui/' + (typeof process.getuid === 'function' ? process.getuid() : 0);
  try { execFileSync('/bin/launchctl', ['bootout', domain + '/' + app.label], { stdio: 'ignore' }); } catch (e) {}
  execFileSync('/bin/launchctl', ['bootstrap', domain, app.file], { stdio: 'inherit' });
  execFileSync('/usr/bin/open', ['http://127.0.0.1:47921/']);
  console.log('Installed. Daily beta folders were not changed.');
}

if (require.main === module) install();
module.exports = { install };
