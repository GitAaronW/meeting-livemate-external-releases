#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")"
case "$(uname -m)" in
  arm64) NODE="./runtime/node-v22.23.2-darwin-arm64/bin/node" ;;
  x86_64) NODE="./runtime/node-v22.23.2-darwin-x64/bin/node" ;;
  *) echo "This Mac is not supported."; exit 1 ;;
esac
if [[ ! -x "$NODE" ]]; then
  NODE="$(command -v node || true)"
fi
if [[ -z "${NODE}" ]]; then
  echo "This package has no Node runtime, and this Mac has no Node."
  exit 1
fi
exec "$NODE" "./scripts/install.js"
