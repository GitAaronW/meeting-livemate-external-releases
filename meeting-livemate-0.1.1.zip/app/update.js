'use strict';
const https = require('https');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const UPDATE_REPO = 'GitAaronW/meeting-livemate-external-releases';
const BLOCKED_REPOS = ['GitAaronW/meeting-livemate-releases'];

function localVersion(root = path.join(__dirname, '..')) {
  try { return JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).version || '0.0.0'; }
  catch (e) { return '0.0.0'; }
}
function cmp(a, b) {
  const p = s => String(s).split('.').map(n => parseInt(n, 10) || 0);
  const x = p(a), y = p(b);
  for (let i = 0; i < 3; i++) {
    if ((x[i] || 0) > (y[i] || 0)) return 1;
    if ((x[i] || 0) < (y[i] || 0)) return -1;
  }
  return 0;
}
function manifestUrl(repo = UPDATE_REPO) {
  if (BLOCKED_REPOS.includes(repo)) throw new Error('This build does not update from the older trial feed.');
  return 'https://raw.githubusercontent.com/' + repo + '/main/version.json';
}
function check(options = {}) {
  const current = options.current || localVersion(options.root);
  const get = options.get || defaultGet;
  return get(manifestUrl(options.repo || UPDATE_REPO)).then(body => {
    const man = JSON.parse(body);
    if (!man || !/^\d+\.\d+\.\d+$/.test(String(man.version || ''))) {
      return { ok: false, current, code: 'update_feed_invalid' };
    }
    return {
      ok: true,
      current,
      latest: man.version,
      hasUpdate: cmp(man.version, current) > 0,
      notes: String(man.notes || ''),
      zip: String(man.zip || ''),
      sha256: String(man.sha256 || '').trim().toLowerCase(),
    };
  }).catch(() => ({ ok: false, current, code: 'update_feed_unavailable' }));
}
const SKIP = new Set(['data', '.git', 'settings.json', 'meetings']);
function assertApplyRoot(root) {
  const resolved = path.resolve(root) + path.sep;
  const bad = ['/Tinghuitai/', '/TinghuitaiUS/', '/TinghuitaiAaron/', '/.worktrees/'];
  if (bad.some(part => resolved.includes(part))) throw new Error('Refusing to replace this copy.');
}
function findPackage(dir) {
  if (fs.existsSync(path.join(dir, 'package.json')) && fs.existsSync(path.join(dir, 'app'))) return dir;
  let found = null;
  for (const name of fs.readdirSync(dir)) {
    if (name.startsWith('.') || name.startsWith('__') || name === 'p.zip') continue;
    const child = path.join(dir, name);
    if (fs.statSync(child).isDirectory()) found = findPackage(child) || found;
  }
  return found;
}
function applyZip({ root, zipPath, sha256 }) {
  assertApplyRoot(root);
  const want = String(sha256 || '').trim().toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(want)) throw new Error('The update has no checksum. It was not installed.');
  const got = crypto.createHash('sha256').update(fs.readFileSync(zipPath)).digest('hex');
  if (got !== want) throw new Error('The download checksum did not match. It was not installed.');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'mlm-update-'));
  try {
    execFileSync('/usr/bin/unzip', ['-q', '-o', zipPath, '-d', tmp], { stdio: 'ignore' });
    const src = findPackage(tmp);
    if (!src) throw new Error('The update package has no app. It was not installed.');
    fs.mkdirSync(root, { recursive: true });
    for (const name of fs.readdirSync(src)) {
      if (SKIP.has(name)) continue;
      fs.cpSync(path.join(src, name), path.join(root, name), { recursive: true, force: true });
    }
    try { execFileSync('/usr/bin/xattr', ['-dr', 'com.apple.quarantine', root], { stdio: 'ignore' }); } catch (e) {}
    return { updated: true, version: localVersion(root) };
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}
function zipUrl(name) {
  if (!/^[A-Za-z0-9._-]+$/.test(String(name || ''))) throw new Error('The update package name is not valid.');
  return 'https://raw.githubusercontent.com/' + UPDATE_REPO + '/main/' + name;
}
async function downloadAndApply({ root, getBuffer } = {}) {
  assertApplyRoot(root);
  const info = await check({ root });
  if (!info.ok) return { ok: false, updated: false, code: info.code, error: 'No update feed is reachable yet.' };
  if (!info.hasUpdate) return { ok: true, updated: false, current: info.current };
  const buf = await (getBuffer || defaultGetBuffer)(zipUrl(info.zip));
  const zipPath = path.join(os.tmpdir(), 'mlm-zip-' + crypto.randomBytes(4).toString('hex') + '.zip');
  fs.writeFileSync(zipPath, buf);
  try {
    const applied = applyZip({ root, zipPath, sha256: info.sha256 });
    return { ok: true, ...applied };
  } finally {
    fs.rmSync(zipPath, { force: true });
  }
}
function defaultGet(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': 'meeting-livemate' } }, res => {
      if (res.statusCode !== 200) { res.resume(); reject(new Error('HTTP ' + res.statusCode)); return; }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    });
    req.setTimeout(8000, () => req.destroy(new Error('timeout')));
    req.on('error', reject);
  });
}
function defaultGetBuffer(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': 'meeting-livemate' } }, res => {
      if (res.statusCode !== 200) { res.resume(); reject(new Error('HTTP ' + res.statusCode)); return; }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.setTimeout(20000, () => req.destroy(new Error('timeout')));
    req.on('error', reject);
  });
}
module.exports = { UPDATE_REPO, BLOCKED_REPOS, manifestUrl, check, cmp, localVersion, assertApplyRoot, applyZip, downloadAndApply, zipUrl };
