#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")"
exec node "./scripts/install.js"
