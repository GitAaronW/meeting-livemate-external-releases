'use strict';
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const root = path.resolve(__dirname, '..');
const skip = new Set(['node_modules', '.git']);
const banned = ['Q2hhbnNleQ==', 'MjYxOTE=', 'Q2l0ZXNpZGU=', 'bm90aGluZy50ZWNo', 'QkVHSU4gUFJJVkFURSBLRVk=', 'UkVMQVlfVE9LRU49'].map(s => Buffer.from(s, 'base64').toString('utf8'));
const han = /[\u4e00-\u9fff]/;
const hits = [];

function walk(dir) {
  for (const name of fs.readdirSync(dir)) {
    if (skip.has(name)) continue;
    const file = path.join(dir, name);
    const stat = fs.statSync(file);
    if (stat.isDirectory()) { walk(file); continue; }
    const rel = path.relative(root, file);
    if (stat.size > 2000000) { hits.push(rel + ': file is unexpectedly large'); continue; }
    const buf = fs.readFileSync(file);
    const text = buf.toString('utf8');
    if (buf.includes(0)) {
      let strings = '';
      try { strings = execFileSync('/usr/bin/strings', ['-a', '-n', '4', file], { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 }); }
      catch (e) { strings = text; }
      for (const word of banned) if (strings.includes(word)) hits.push(rel + ': banned word in binary');
      if (han.test(strings)) hits.push(rel + ': non-English text in binary');
      continue;
    }
    const lines = text.split(/\n/);
    lines.forEach((line, i) => {
      if (han.test(line)) hits.push(rel + ':' + (i + 1));
      for (const word of banned) if (line.includes(word)) hits.push(rel + ':' + (i + 1) + ' banned');
    });
  }
}
walk(root);
if (hits.length) {
  console.error('gate failed ' + hits.length);
  console.error(hits.slice(0, 30).join('\n'));
  process.exit(1);
}
console.log('gate passed');
