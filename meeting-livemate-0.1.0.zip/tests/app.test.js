'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { spawnSync } = require('child_process');
const { start, assertSafe } = require('../app/server');
const update = require('../app/update');
const share = require('../app/share');
const startup = require('../app/startup');
const { summarize } = require('../app/summary');

function get(port, pathname) {
  return new Promise((resolve, reject) => {
    http.get({ hostname: '127.0.0.1', port, path: pathname }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString('utf8') }));
    }).on('error', reject);
  });
}
function post(port, pathname, body) {
  return new Promise((resolve, reject) => {
    const req = http.request({ hostname: '127.0.0.1', port, path: pathname, method: 'POST', headers: { 'Content-Type': 'application/json' } }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString('utf8') }));
    });
    req.on('error', reject);
    req.end(JSON.stringify(body || {}));
  });
}

test('refuses the daily beta directories and ports', () => {
  assert.throws(() => assertSafe('/tmp/Tinghuitai', 47921), /daily beta data/);
  assert.throws(() => assertSafe('/tmp/MeetingLiveMate', 47823), /daily beta port/);
  assert.throws(() => assertSafe('/tmp/MeetingLiveMate', 47911), /daily beta port/);
  assert.doesNotThrow(() => assertSafe('/tmp/MeetingLiveMate', 47921));
});

test('update feed is the external releases repo', async () => {
  assert.equal(update.UPDATE_REPO, 'GitAaronW/meeting-livemate-external-releases');
  assert.throws(() => update.manifestUrl('GitAaronW/meeting-livemate-releases'), /older trial feed/);
  const out = await update.check({
    current: '0.1.0',
    get: async () => JSON.stringify({ version: '0.1.1', notes: 'Fix the installer.' }),
  });
  assert.equal(out.hasUpdate, true);
  assert.equal(out.latest, '0.1.1');
});

test('share page omits the transcript', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mlm-share-'));
  const published = share.publish(share.fileOf(dir), {
    meetingId: 'meet1234',
    title: 'Planning',
    date: '2026-10-27',
    summary: 'Ship the English build.',
    todos: 'Send the package.',
    transcript: 'secret sentence',
  });
  const page = share.html(share.readPublic(share.fileOf(dir), published.token));
  assert.match(page, /Ship the English build/);
  assert.doesNotMatch(page, /secret sentence/);
  assert.equal(share.revoke(share.fileOf(dir), published.token), true);
  assert.equal(share.readPublic(share.fileOf(dir), published.token), null);
});

test('server health, settings, and share stay on this Mac', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mlm-app-'));
  const server = await start({ dataDir: dir, port: 0, root: path.join(__dirname, '..') });
  const port = server.address().port;
  assert.ok(![47823, 47911, 47921].includes(port));
  try {
    const health = JSON.parse((await get(port, '/health')).body);
    assert.equal(health.ok, true);
    assert.equal(health.edition, 'external');
    const page = await get(port, '/');
    assert.equal(page.status, 200);
    assert.match(page.body, /No bot joins your call/);
    assert.doesNotMatch(page.body, /[\u4e00-\u9fff]/);
    const saved = JSON.parse((await post(port, '/settings', { transcriptionKey: 'test-key', summaryHost: 'api.fireworks.ai' })).body);
    assert.equal(saved.hasTranscriptionKey, true);
    const view = JSON.parse((await get(port, '/settings')).body);
    assert.equal(view.hasTranscriptionKey, true);
    assert.equal(view.transcriptionKey, undefined);
    const created = JSON.parse((await post(port, '/meetings', {})).body);
    const shared = JSON.parse((await post(port, '/meetings/' + created.meeting.id + '/share', {})).body);
    const note = await get(port, shared.path);
    assert.equal(note.status, 200);
    assert.match(note.body, /The transcript and the audio are not on this page/);
    const bad = JSON.parse((await post(port, '/settings', { summaryHost: 'api.deepseek.com' })).body);
    assert.equal(bad.ok, false);
    const blocked = JSON.parse((await post(port, '/update/apply', {})).body);
    assert.equal(blocked.code, 'not_installed_copy');
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});

test('summary uses the saved key and keeps the transcript out of the page', async () => {
  let called = 0;
  const fetchImpl = async () => {
    called += 1;
    return { json: async () => ({ choices: [{ message: { content: '{"summary":"Ship the English build.","todos":"Send the package."}' } }] }) };
  };
  await assert.rejects(() => summarize({ host: 'api.fireworks.ai', key: '', transcript: 'hello', fetchImpl }), /summary key/);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mlm-notes-'));
  const server = await start({ dataDir: dir, port: 0, root: path.join(__dirname, '..'), fetchImpl });
  const port = server.address().port;
  assert.ok(![47823, 47911, 47921].includes(port));
  try {
    const id = 'abc123abc123abcd';
    fs.mkdirSync(path.join(dir, 'meetings'), { recursive: true });
    fs.writeFileSync(path.join(dir, 'meetings', id + '.json'), JSON.stringify({
      id, title: 'Planning', date: '2026-10-27', lines: ['We will ship the English build.'], summary: '', todos: '',
    }));
    await post(port, '/settings', { summaryKey: 'summary-test', summaryHost: 'api.fireworks.ai' });
    const notes = JSON.parse((await post(port, '/meetings/' + id + '/summary', {})).body);
    assert.equal(notes.ok, true);
    assert.equal(notes.summary, 'Ship the English build.');
    assert.equal(called, 1);
    const shared = JSON.parse((await post(port, '/meetings/' + id + '/share', {})).body);
    const page = await get(port, shared.path);
    assert.match(page.body, /Ship the English build/);
    assert.doesNotMatch(page.body, /We will ship the English build/);
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});

test('update replaces program files and leaves notes in place', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'mlm-old-'));
  const next = fs.mkdtempSync(path.join(os.tmpdir(), 'mlm-new-'));
  fs.mkdirSync(path.join(root, 'app'), { recursive: true });
  fs.mkdirSync(path.join(root, 'data'), { recursive: true });
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ version: '0.1.0' }));
  fs.writeFileSync(path.join(root, 'app', 'keep.txt'), 'old');
  fs.writeFileSync(path.join(root, 'data', 'secret.txt'), 'keep-me');
  fs.mkdirSync(path.join(next, 'app'), { recursive: true });
  fs.writeFileSync(path.join(next, 'package.json'), JSON.stringify({ version: '0.1.1' }));
  fs.writeFileSync(path.join(next, 'app', 'keep.txt'), 'new');
  const zip = path.join(os.tmpdir(), 'mlm-' + Date.now() + '.zip');
  const packed = spawnSync('/usr/bin/zip', ['-q', '-r', zip, 'package.json', 'app'], { cwd: next });
  assert.equal(packed.status, 0, packed.stderr && packed.stderr.toString());
  const sha = require('crypto').createHash('sha256').update(fs.readFileSync(zip)).digest('hex');
  assert.throws(() => update.applyZip({ root, zipPath: zip, sha256: '0'.repeat(64) }), /checksum/);
  assert.equal(fs.readFileSync(path.join(root, 'app', 'keep.txt'), 'utf8'), 'old');
  const applied = update.applyZip({ root, zipPath: zip, sha256: sha });
  assert.equal(applied.updated, true);
  assert.equal(applied.version, '0.1.1');
  assert.equal(fs.readFileSync(path.join(root, 'app', 'keep.txt'), 'utf8'), 'new');
  assert.equal(fs.readFileSync(path.join(root, 'data', 'secret.txt'), 'utf8'), 'keep-me');
  fs.rmSync(zip, { force: true });
});

test('startup file stays in a temporary home', () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'mlm-home-'));
  const dataDir = path.join(home, 'MeetingLiveMate');
  const root = path.join(home, 'program');
  fs.mkdirSync(root, { recursive: true });
  const calls = [];
  const app = startup.create({
    dataDir, home, root, platform: 'darwin', uid: 501, node: '/usr/bin/node',
    run: (cmd, args) => { calls.push(cmd + ' ' + args.join(' ')); },
  });
  const wrote = app.set(true);
  assert.equal(wrote.configured, true);
  const plist = fs.readFileSync(app.file, 'utf8');
  assert.match(plist, /THT_EDITION/);
  assert.match(plist, /47921/);
  assert.doesNotMatch(plist, /47823/);
  app.desktop();
  assert.match(fs.readFileSync(app.shortcut, 'utf8'), /server\.js/);
  assert.ok(calls.some(line => line.includes('plutil')));
});

test('source gate passes', () => {
  const run = spawnSync(process.execPath, [path.join(__dirname, '../scripts/gate.js')], { encoding: 'utf8' });
  assert.equal(run.status, 0, run.stderr);
  assert.match(run.stdout, /gate passed/);
});
