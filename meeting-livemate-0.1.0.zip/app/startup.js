'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const xml = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]));

function create({ dataDir, port = 47921, home = os.homedir(), root = path.resolve(__dirname, '..'), node = process.execPath, platform = process.platform, run = execFileSync, uid = process.getuid?.() || 0 }) {
  const label = 'com.livemate.external.' + crypto.createHash('sha256').update(dataDir).digest('hex').slice(0, 12);
  const file = path.join(home, 'Library/LaunchAgents', label + '.plist');
  const shortcut = path.join(home, 'Desktop/Meeting LiveMate.command');
  function status() {
    let enabled = false;
    if (platform === 'darwin') {
      try { run('/bin/launchctl', ['print', 'gui/' + uid + '/' + label], { stdio: 'ignore' }); enabled = true; } catch (e) { enabled = false; }
    }
    return { supported: platform === 'darwin', enabled, configured: fs.existsSync(file), label, port };
  }
  function set(enabled) {
    if (platform !== 'darwin') throw new Error('Install is available on macOS.');
    if (typeof enabled !== 'boolean') throw new Error('invalid startup');
    if (!enabled) {
      try { run('/bin/launchctl', ['bootout', 'gui/' + uid + '/' + label], { stdio: 'ignore' }); } catch (e) {}
      if (fs.existsSync(file)) fs.unlinkSync(file);
      return status();
    }
    if (fs.existsSync(file) && !fs.readFileSync(file, 'utf8').includes(xml(root + '/app/server.js'))) {
      throw new Error('A different startup file already uses this name. It was left in place.');
    }
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const log = path.join(dataDir, 'launcher.log');
    const plist = `<?xml version="1.0"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict><key>Label</key><string>${xml(label)}</string><key>ProgramArguments</key><array><string>${xml(node)}</string><string>${xml(root + '/app/server.js')}</string></array><key>WorkingDirectory</key><string>${xml(root)}</string><key>EnvironmentVariables</key><dict><key>THT_DATA_DIR</key><string>${xml(dataDir)}</string><key>THT_PORT</key><string>${xml(String(port))}</string><key>THT_EDITION</key><string>external</string></dict><key>RunAtLoad</key><true/><key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict><key>ThrottleInterval</key><integer>10</integer><key>StandardOutPath</key><string>${xml(log)}</string><key>StandardErrorPath</key><string>${xml(log)}</string></dict></plist>`;
    fs.writeFileSync(file, plist, { mode: 0o600 });
    run('/usr/bin/plutil', ['-lint', file], { stdio: 'ignore' });
    return { ...status(), configured: true, nextLogin: true };
  }
  function desktop() {
    if (platform !== 'darwin') throw new Error('Install is available on macOS.');
    const text = '#!/bin/zsh\n# Meeting LiveMate\nexport THT_EDITION=external\nexport THT_PORT=' + port + '\nexport THT_DATA_DIR=' + "'" + String(dataDir).replace(/'/g, "'\\''") + "'" + '\nexec ' + "'" + node.replace(/'/g, "'\\''") + "' '" + path.join(root, 'app/server.js').replace(/'/g, "'\\''") + "'\n";
    fs.mkdirSync(path.dirname(shortcut), { recursive: true });
    fs.writeFileSync(shortcut, text, { mode: 0o700 });
    return status();
  }
  return { status, set, desktop, file, label, shortcut };
}
module.exports = { create };
