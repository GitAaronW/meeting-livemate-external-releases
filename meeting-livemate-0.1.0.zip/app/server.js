'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
const { DeepgramAsr } = require('./deepgram');
const { MacAsr, available: macAvailable } = require('./mac-asr');
const share = require('./share');
const update = require('./update');
const { summarize } = require('./summary');

const FORBIDDEN_DIRS = new Set(['Tinghuitai', 'TinghuitaiUS', 'TinghuitaiAaron']);
const FORBIDDEN_PORTS = new Set([47823, 47911]);
const SUMMARY_HOSTS = new Set(['api.fireworks.ai', 'api.openai.com', 'api.groq.com', 'api.together.xyz', 'api.together.ai']);

function assertSafe(dataDir, port) {
  const base = path.basename(path.resolve(dataDir));
  if (FORBIDDEN_DIRS.has(base)) throw new Error('Refusing the daily beta data directory.');
  if (FORBIDDEN_PORTS.has(Number(port))) throw new Error('Refusing a daily beta port.');
}

function settingsFile(dataDir) { return path.join(dataDir, 'settings.json'); }
function readSettings(dataDir) {
  try { return JSON.parse(fs.readFileSync(settingsFile(dataDir), 'utf8')); }
  catch (e) { return {}; }
}
function writeSettings(dataDir, next) {
  fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  const file = settingsFile(dataDir);
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(next), { mode: 0o600 });
  fs.chmodSync(tmp, 0o600);
  fs.renameSync(tmp, file);
}
function meetingFile(dataDir, id) { return path.join(dataDir, 'meetings', id + '.json'); }
function readMeeting(dataDir, id) {
  try { return JSON.parse(fs.readFileSync(meetingFile(dataDir, id), 'utf8')); }
  catch (e) { return null; }
}
function writeMeeting(dataDir, meeting) {
  const dir = path.join(dataDir, 'meetings');
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const file = meetingFile(dataDir, meeting.id);
  fs.writeFileSync(file, JSON.stringify(meeting), { mode: 0o600 });
}
function publicMeeting(meeting) {
  if (!meeting) return null;
  return {
    id: meeting.id,
    title: meeting.title || 'Meeting',
    date: meeting.date,
    lines: meeting.lines || [],
    partial: meeting.partial || '',
    summary: meeting.summary || '',
    todos: meeting.todos || '',
  };
}
function send(res, code, body, type) {
  const buf = Buffer.from(body);
  res.writeHead(code, { 'Content-Type': type, 'Content-Length': buf.length, 'Cache-Control': 'no-store' });
  res.end(buf);
}
function json(res, code, obj) { send(res, code, JSON.stringify(obj), 'application/json; charset=utf-8'); }
function readBody(req, limit = 200000) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let n = 0;
    req.on('data', c => {
      n += c.length;
      if (n > limit) { reject(Object.assign(new Error('Body too large.'), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch (e) { reject(Object.assign(new Error('Bad JSON.'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
function local(req) {
  const host = String(req.socket.remoteAddress || '');
  return host === '127.0.0.1' || host === '::1' || host === '::ffff:127.0.0.1';
}

function createServer({ dataDir, port, root = path.join(__dirname, '..'), fetchImpl } = {}) {
  assertSafe(dataDir, port);
  fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  const meetings = new Map();
  const server = http.createServer(async (req, res) => {
    try {
      const u = new URL(req.url, 'http://127.0.0.1');
      if (req.method === 'GET' && (u.pathname === '/' || u.pathname === '/index.html')) {
        send(res, 200, fs.readFileSync(path.join(root, 'web/index.html')), 'text/html; charset=utf-8');
        return;
      }
      if (req.method === 'GET' && u.pathname === '/health') {
        json(res, 200, { ok: true, edition: 'external', port: Number(port), activeSessions: [...meetings.values()].filter(s => s.engine).length });
        return;
      }
      const pub = u.pathname.match(/^\/s\/([A-Za-z0-9_-]*)$/);
      if (pub && (req.method === 'GET' || req.method === 'HEAD')) {
        const rec = share.readPublic(share.fileOf(dataDir), pub[1]);
        if (!rec) { send(res, 404, 'This note is not available.', 'text/plain; charset=utf-8'); return; }
        send(res, 200, req.method === 'HEAD' ? '' : share.html(rec), 'text/html; charset=utf-8');
        return;
      }
      if (!local(req)) { json(res, 403, { ok: false, error: 'Open this on the Mac that is running Meeting LiveMate.' }); return; }
      if (req.method === 'GET' && u.pathname === '/settings') {
        const s = readSettings(dataDir);
        json(res, 200, {
          ok: true,
          hasTranscriptionKey: !!s.transcriptionKey,
          hasSummaryKey: !!s.summaryKey,
          summaryHost: s.summaryHost || '',
          macSpeech: macAvailable(),
        });
        return;
      }
      if (req.method === 'POST' && u.pathname === '/settings') {
        const body = await readBody(req, 8000);
        const prev = readSettings(dataDir);
        const next = { ...prev };
        if (typeof body.transcriptionKey === 'string') next.transcriptionKey = body.transcriptionKey.trim();
        if (typeof body.summaryKey === 'string') next.summaryKey = body.summaryKey.trim();
        if (typeof body.summaryHost === 'string') {
          if (body.summaryHost && !SUMMARY_HOSTS.has(body.summaryHost)) {
            json(res, 400, { ok: false, error: 'That summary host is not available in this build.' });
            return;
          }
          next.summaryHost = body.summaryHost;
        }
        writeSettings(dataDir, next);
        json(res, 200, { ok: true, hasTranscriptionKey: !!next.transcriptionKey, hasSummaryKey: !!next.summaryKey });
        return;
      }
      if (req.method === 'GET' && u.pathname === '/update') {
        json(res, 200, await update.check({ root }));
        return;
      }
      if (req.method === 'POST' && u.pathname === '/update/apply') {
        try { update.assertApplyRoot(root); }
        catch (e) {
          json(res, 200, { ok: false, code: 'not_installed_copy', error: 'Install the package before updating this copy.' });
          return;
        }
        json(res, 200, await update.downloadAndApply({ root }));
        return;
      }
      if (req.method === 'POST' && u.pathname === '/meetings') {
        const id = crypto.randomBytes(8).toString('hex');
        const meeting = { id, title: 'Meeting', date: new Date().toISOString().slice(0, 10), lines: [], partial: '', summary: '', todos: '' };
        meetings.set(id, { meeting, engine: null });
        writeMeeting(dataDir, meeting);
        json(res, 200, { ok: true, meeting: publicMeeting(meeting) });
        return;
      }
      const summaryRoute = u.pathname.match(/^\/meetings\/([a-f0-9]{16})\/summary$/);
      const shared = u.pathname.match(/^\/meetings\/([a-f0-9]{16})\/share$/);
      const one = u.pathname.match(/^\/meetings\/([a-f0-9]{16})$/);
      if (one && req.method === 'GET') {
        const live = meetings.get(one[1]);
        const meeting = live ? live.meeting : readMeeting(dataDir, one[1]);
        if (!meeting) { json(res, 404, { ok: false, error: 'No such meeting.' }); return; }
        json(res, 200, { ok: true, meeting: publicMeeting(meeting) });
        return;
      }
      if (summaryRoute && req.method === 'POST') {
        const live = meetings.get(summaryRoute[1]);
        const meeting = live ? live.meeting : readMeeting(dataDir, summaryRoute[1]);
        if (!meeting) { json(res, 404, { ok: false, error: 'No such meeting.' }); return; }
        const settings = readSettings(dataDir);
        const notes = await summarize({
          host: settings.summaryHost,
          key: settings.summaryKey,
          transcript: (meeting.lines || []).join('\n'),
          fetchImpl,
        });
        meeting.summary = notes.summary;
        meeting.todos = notes.todos;
        writeMeeting(dataDir, meeting);
        json(res, 200, { ok: true, summary: notes.summary, todos: notes.todos });
        return;
      }
      if (shared && req.method === 'POST') {
        const live = meetings.get(shared[1]);
        const meeting = live ? live.meeting : readMeeting(dataDir, shared[1]);
        if (!meeting) { json(res, 404, { ok: false, error: 'No such meeting.' }); return; }
        const published = share.publish(share.fileOf(dataDir), {
          meetingId: meeting.id,
          title: meeting.title,
          date: meeting.date,
          summary: meeting.summary,
          todos: meeting.todos,
        });
        json(res, 200, { ok: true, ...published });
        return;
      }
      json(res, 404, { ok: false, error: 'Not found.' });
    } catch (e) {
      json(res, e.status || 500, { ok: false, error: String(e.message || 'Request failed.').slice(0, 200) });
    }
  });
  const wss = new WebSocketServer({ noServer: true });
  server.on('upgrade', (req, socket, head) => {
    if (!local(req)) { socket.destroy(); return; }
    const u = new URL(req.url, 'http://127.0.0.1');
    if (u.pathname !== '/listen') { socket.destroy(); return; }
    wss.handleUpgrade(req, socket, head, ws => listen(ws, u.searchParams.get('meeting') || ''));
  });
  function listen(ws, meetingId) {
    const slot = meetings.get(meetingId);
    if (!slot) { ws.close(1008, 'No such meeting.'); return; }
    const settings = readSettings(dataDir);
    const onResult = (msg) => {
      if (msg.type === 'final' && msg.text) {
        slot.meeting.lines.push(msg.text);
        slot.meeting.partial = '';
        writeMeeting(dataDir, slot.meeting);
      } else if (msg.type === 'partial') slot.meeting.partial = msg.text || '';
      if (ws.readyState === 1) ws.send(JSON.stringify(msg));
    };
    const engine = settings.transcriptionKey
      ? new DeepgramAsr('en', settings.transcriptionKey, onResult)
      : (macAvailable() ? new MacAsr('en', onResult) : null);
    if (!engine) {
      ws.send(JSON.stringify({ type: 'fatal', text: 'Add a transcription key in Settings. A summary key is optional.' }));
      ws.close();
      return;
    }
    slot.engine = engine;
    engine.start();
    ws.on('message', buf => { if (Buffer.isBuffer(buf)) engine.write(buf); });
    ws.on('close', () => { engine.stop(); slot.engine = null; });
  }
  return server;
}

function start(options = {}) {
  const dataDir = options.dataDir || process.env.THT_DATA_DIR || path.join(os.homedir(), 'Library/Application Support/MeetingLiveMate');
  const port = Number(options.port ?? process.env.THT_PORT ?? 47921);
  const server = createServer({ dataDir, port, root: options.root, fetchImpl: options.fetchImpl });
  return new Promise(resolve => server.listen(port, '127.0.0.1', () => resolve(server)));
}

module.exports = { createServer, start, assertSafe, FORBIDDEN_DIRS, FORBIDDEN_PORTS, SUMMARY_HOSTS };

if (require.main === module) {
  start().then(server => {
    const addr = server.address();
    console.log('Meeting LiveMate http://127.0.0.1:' + addr.port);
  }).catch(e => { console.error(e.message); process.exit(1); });
}
