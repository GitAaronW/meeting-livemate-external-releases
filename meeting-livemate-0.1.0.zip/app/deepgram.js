'use strict';
// Streaming transcription. 16 kHz mono PCM in, sentence JSON back. mip_opt_out stays on.
const WebSocket = require('ws');
const LANG = { zh: 'zh-CN', en: 'en-US', id: 'id', pt: 'pt-BR', es: 'es' };

class DeepgramAsr {
  constructor(lang, key, onResult, log = () => {}) {
    this.lang = LANG[lang] || 'en-US';
    this.key = key;
    this.onResult = onResult;
    this.log = log;
    this.ws = null;
    this.dead = false;
    this.retries = 0;
    this.queue = [];
    this.queued = 0;
    this.droppedBytes = 0;
  }
  start() {
    if (this.dead) return;
    if (this.ws) {
      try { this.ws.removeAllListeners(); this.ws.close(); } catch (e) {}
      this.ws = null;
    }
    if (this.retryTimer) { clearTimeout(this.retryTimer); this.retryTimer = null; }
    if (!this.key) {
      this.onResult({ type: 'fatal', text: 'Add a transcription key in Settings.' });
      return;
    }
    const p = new URLSearchParams({
      model: 'nova-3', language: this.lang, encoding: 'linear16', sample_rate: '16000',
      channels: '1', punctuate: 'true', smart_format: 'true', interim_results: 'true', endpointing: '800',
      mip_opt_out: 'true',
    });
    let ws;
    try {
      ws = new WebSocket('wss://api.deepgram.com/v1/listen?' + p, { headers: { Authorization: 'Token ' + this.key } });
    } catch (e) {
      this.onResult({ type: 'fatal', text: 'Could not reach the transcription service: ' + e.message });
      return;
    }
    this.ws = ws;
    ws.on('open', () => { this.log('transcription connected ' + this.lang); this.flush(); });
    ws.on('message', d => {
      let j;
      try { j = JSON.parse(d.toString()); } catch (e) { return; }
      if (j.type === 'Error' || j.error) {
        const msg = String(j.error || j.description || j.message || '').slice(0, 160);
        const permanent = /unauthor|forbidden|invalid.*key|quota|credit|payment|suspend/i.test(msg);
        if (permanent) {
          this.dead = true;
          try { ws.close(); } catch (e) {}
          this.onResult({ type: 'fatal', text: 'The transcription service rejected this request: ' + msg });
        } else {
          this.log('retryable transcription error: ' + msg);
          try { ws.close(); } catch (e) {}
        }
        return;
      }
      const alt = j.channel && j.channel.alternatives && j.channel.alternatives[0];
      const text = (alt && alt.transcript || '').trim();
      if (!text) return;
      this.retries = 0;
      this.onResult({ type: j.is_final ? 'final' : 'partial', text });
    });
    ws.on('close', (code) => {
      this.ws = null;
      if (this.dead) return;
      if (code === 1008 || code === 4001 || code === 401) {
        this.onResult({ type: 'fatal', text: 'The transcription key was rejected. Check Settings.' });
        this.dead = true;
        return;
      }
      if (this.retries++ < 5) {
        this.log('transcription closed (' + code + '), retry ' + this.retries);
        this.retryTimer = setTimeout(() => this.start(), 800 * this.retries);
      } else this.onResult({ type: 'fatal', text: 'Transcription kept disconnecting. Retry stopped.' });
    });
    ws.on('error', e => {
      const m = String(e && e.message || '');
      this.log('transcription error ' + m);
      if (/\b40[13]\b/.test(m)) {
        this.dead = true;
        this.onResult({ type: 'fatal', text: 'The transcription key was rejected. Check Settings.' });
      }
    });
  }
  flush() { const q = this.queue; this.queue = []; this.queued = 0; for (const b of q) this.write(b); }
  write(pcm) {
    const w = this.ws;
    if (w && w.readyState === WebSocket.OPEN) {
      try { w.send(pcm); } catch (e) { this.log('transcription send failed ' + e.message); }
      return;
    }
    if (this.dead) return;
    const buf = Buffer.isBuffer(pcm) ? pcm
      : (ArrayBuffer.isView(pcm) ? Buffer.from(Buffer.from(pcm.buffer, pcm.byteOffset, pcm.byteLength)) : Buffer.from(pcm));
    this.queue.push(buf);
    this.queued += buf.length;
    while (this.queue.length && this.queued > 32000 * 20) {
      const b = this.queue.shift();
      this.queued -= (b ? b.length : 0);
      this.droppedBytes += (b ? b.length : 0);
    }
    if (!this.queue.length) this.queued = 0;
  }
  drain(ms = 6000) {
    return new Promise(res => {
      this.dead = true;
      if (this.retryTimer) { clearTimeout(this.retryTimer); this.retryTimer = null; }
      const w = this.ws;
      if (!w) return res();
      if (w.readyState === WebSocket.CONNECTING) {
        w.once('open', () => { try { w.send(JSON.stringify({ type: 'CloseStream' })); } catch (e) {} });
      } else if (w.readyState !== WebSocket.OPEN) {
        try { w.close(); } catch (e) {}
        return res();
      }
      let done = false;
      let timer = null;
      const fin = () => { if (done) return; done = true; if (timer) clearTimeout(timer); try { w.close(); } catch (e) {} res(); };
      w.once('close', fin);
      timer = setTimeout(fin, ms);
      try { w.send(JSON.stringify({ type: 'CloseStream' })); } catch (e) { fin(); }
    });
  }
  stop() {
    this.dead = true;
    if (this.retryTimer) { clearTimeout(this.retryTimer); this.retryTimer = null; }
    try { this.ws && this.ws.close(); } catch (e) {}
    this.ws = null;
  }
}
module.exports = { DeepgramAsr, LANG };
