'use strict';
// On-device speech recognition. Launch the .app through LaunchServices so it owns the privacy prompt.
// Node must not spawn the binary directly. Audio comes back over a 127.0.0.1 port, not a pipe.
const { execFile } = require('child_process');
const path = require('path');
const fs = require('fs');
const net = require('net');
const crypto = require('crypto');
const APP = path.join(__dirname, 'mac-asr', 'TinghuitaiSpeech.app');
const BIN = path.join(APP, 'Contents', 'MacOS', 'transcriber');
const LOCALE = { zh: 'zh-CN', en: 'en-US', id: 'id-ID', pt: 'pt-BR', es: 'es-ES' };
const available = () => {
  try { return process.platform === 'darwin' && process.arch === 'arm64' && fs.existsSync(BIN); }
  catch (e) { return false; }
};

class MacAsr {
  constructor(lang, onResult, log = () => {}) {
    this.locale = LOCALE[lang] || 'en-US';
    this.onResult = onResult;
    this.log = log;
    this.token = crypto.randomBytes(16).toString('hex');
    this.server = null;
    this.sock = null;
    this.ready = false;
    this.dead = false;
    this.restarts = 0;
    this.buf = '';
    this.pending = [];
    this.pendingBytes = 0;
    this.droppedBytes = 0;
  }
  start() {
    if (this.dead) return;
    if (!available()) {
      this.onResult({ type: 'fatal', text: 'On-device transcription is not on this Mac.' });
      return;
    }
    this.server = net.createServer(sock => {
      if (this.sock) { sock.destroy(); return; }
      let authed = false;
      sock.on('data', d => {
        this.buf += d.toString('utf8');
        let i;
        while ((i = this.buf.indexOf('\n')) >= 0) {
          const line = this.buf.slice(0, i);
          this.buf = this.buf.slice(i + 1);
          if (!authed) {
            if (line.trim() !== this.token) { this.log('transcription handshake failed'); sock.destroy(); return; }
            authed = true;
            this.sock = sock;
            continue;
          }
          let j;
          try { j = JSON.parse(line); } catch (e) { continue; }
          this.accept(j);
        }
      });
      sock.on('close', () => { this.sock = null; this.ready = false; if (!this.dead) this.onExit(); });
      sock.on('error', () => {});
    });
    this.server.listen(0, '127.0.0.1', () => {
      const port = this.server.address().port;
      this.launchedAt = Date.now();
      execFile('/usr/bin/open', ['-n', '-a', APP, '--args', String(port), this.token, this.locale], e => {
        if (e) this.onResult({ type: 'fatal', text: 'Could not start on-device transcription: ' + e.message });
      });
      this.timeout = setTimeout(() => {
        if (!this.ready && !this.dead) {
          this.reap();
          this.onResult({ type: 'fatal', text: 'On-device transcription did not connect. Allow Speech Recognition and the microphone for Meeting LiveMate, then try again.' });
        }
      }, 10000);
    });
  }
  accept(j) {
    if (j.type === 'final' && this.dead && this.onFinalWhileDraining) {
      const cb = this.onFinalWhileDraining;
      this.onFinalWhileDraining = null;
      this.onResult(j);
      setTimeout(cb, 300);
      return;
    }
    if (j.type === 'ready') {
      this.ready = true;
      if (this.timeout) { clearTimeout(this.timeout); this.timeout = null; }
      this.log('on-device transcription ready');
      this.flush();
      return;
    }
    if (j.type === 'final' && String(j.text || '').trim()) this.restarts = 0;
    this.onResult(j);
  }
  onExit() {
    if (this.dead) return;
    if (this.restarts++ < 5) {
      this.log('on-device transcription retry ' + this.restarts);
      this.close();
      this.retryTimer = setTimeout(() => this.start(), 1500);
    } else this.onResult({ type: 'fatal', text: 'On-device transcription kept disconnecting. Retry stopped.' });
  }
  write(pcm) {
    const s = this.sock;
    if (s && !s.destroyed && this.ready) { try { s.write(pcm); } catch (e) {} return; }
    if (this.dead) return;
    this.pending.push(Buffer.from(pcm));
    this.pendingBytes += pcm.length;
    while (this.pending.length && this.pendingBytes > 32000 * 20) {
      const b = this.pending.shift();
      this.pendingBytes -= b.length;
      this.droppedBytes += b.length;
    }
  }
  flush() {
    const s = this.sock;
    if (!s || s.destroyed) return;
    for (const b of this.pending) { try { s.write(b); } catch (e) {} }
    this.pending = [];
    this.pendingBytes = 0;
  }
  reap() {
    if (!this.launchedAt) return;
    this.launchedAt = 0;
    try { execFile('/usr/bin/pkill', ['-f', 'TinghuitaiSpeech.app/Contents/MacOS/transcriber'], () => {}); } catch (e) {}
  }
  close() {
    try { if (this.timeout) clearTimeout(this.timeout); } catch (e) {}
    try { if (this.retryTimer) clearTimeout(this.retryTimer); } catch (e) {}
    try { this.sock && this.sock.destroy(); } catch (e) {}
    try { this.server && this.server.close(); } catch (e) {}
    this.sock = null;
    this.server = null;
    this.ready = false;
  }
  drain(ms = 8000) {
    return new Promise(res => {
      const s = this.sock;
      this.dead = true;
      if (this.timeout) { clearTimeout(this.timeout); this.timeout = null; }
      if (!s || s.destroyed) { this.close(); return res(); }
      let done = false;
      const fin = () => { if (done) return; done = true; try { s.destroy(); } catch (e) {} this.close(); res(); };
      this.onFinalWhileDraining = fin;
      s.once('close', fin);
      setTimeout(fin, ms);
      try { s.end(); } catch (e) { fin(); }
    });
  }
  stop() {
    this.dead = true;
    if (this.timeout) { clearTimeout(this.timeout); this.timeout = null; }
    const s = this.sock;
    if (s && !s.destroyed) {
      try { s.end(); } catch (e) {}
      const tm = setTimeout(() => { try { s.destroy(); } catch (e) {} this.close(); this.reap(); }, 3000);
      if (tm.unref) tm.unref();
    } else { this.close(); this.reap(); }
  }
}
module.exports = { MacAsr, available, BIN, APP };
