'use strict';
// A share link exists only after Share. The page has the summary and the action items.
// The transcript and the audio are not stored in the link. Revoke makes the old link 404.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const MEETING_ID = /^[A-Za-z0-9_-]{1,80}$/;
const TOKEN = /^[A-Za-z0-9_-]{32}$/;
const FIELDS = ['token', 'meetingId', 'title', 'date', 'summary', 'todos', 'createdAt', 'updatedAt', 'revokedAt'];

function fileOf(dataDir) { return path.join(dataDir, 'state', 'share-links.json'); }
function empty() { return { byMeeting: {}, links: {} }; }
function load(file) {
  try {
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    return { byMeeting: j.byMeeting || {}, links: j.links || {} };
  } catch { return empty(); }
}
function save(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  const tmp = file + '.tmp';
  const clean = {
    byMeeting: data.byMeeting || {},
    links: Object.fromEntries(Object.entries(data.links || {}).map(([k, v]) => [k, pick(v)])),
  };
  fs.writeFileSync(tmp, JSON.stringify(clean), { mode: 0o600 });
  fs.chmodSync(tmp, 0o600);
  fs.renameSync(tmp, file);
}
function pick(rec) {
  const out = {};
  for (const k of FIELDS) out[k] = rec && rec[k] != null ? rec[k] : '';
  return out;
}
function esc(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function noteOf(note) {
  const meetingId = String(note.meetingId || '');
  if (!MEETING_ID.test(meetingId)) throw Object.assign(new Error('Bad meeting id.'), { status: 400 });
  return {
    meetingId,
    title: String(note.title || 'Meeting').slice(0, 200),
    date: String(note.date || new Date().toISOString().slice(0, 10)).slice(0, 10),
    summary: String(note.summary || '').slice(0, 20000),
    todos: String(note.todos || '').slice(0, 8000),
  };
}
function publish(file, note) {
  const clean = noteOf(note);
  const data = load(file);
  let token = data.byMeeting[clean.meetingId];
  if (!token || !data.links[token] || data.links[token].revokedAt) {
    token = crypto.randomBytes(24).toString('base64url');
    data.byMeeting[clean.meetingId] = token;
  }
  const now = new Date().toISOString();
  const prev = data.links[token] || {};
  data.links[token] = { ...clean, token, createdAt: prev.createdAt || now, updatedAt: now, revokedAt: '' };
  save(file, data);
  return { token, path: '/s/' + token };
}
function readPublic(file, token) {
  if (!TOKEN.test(token)) return null;
  const rec = load(file).links[token];
  if (!rec || rec.revokedAt) return null;
  return pick(rec);
}
function revoke(file, token) {
  if (!TOKEN.test(String(token || ''))) return false;
  const data = load(file);
  const rec = data.links[token];
  if (!rec || rec.revokedAt) return false;
  rec.revokedAt = new Date().toISOString();
  if (data.byMeeting[rec.meetingId] === token) delete data.byMeeting[rec.meetingId];
  save(file, data);
  return true;
}
function html(rec) {
  const body = rec.summary
    ? '<h2>Summary</h2><pre>' + esc(rec.summary) + '</pre>'
    : '<p>No summary yet.</p>';
  const todos = rec.todos
    ? '<h2>Action items</h2><pre>' + esc(rec.todos) + '</pre>'
    : '';
  return '<!doctype html><html lang="en"><head><meta charset="utf-8"><title>' + esc(rec.title) + '</title>'
    + '<style>body{font:16px/1.45 -apple-system,sans-serif;max-width:40rem;margin:2rem auto;padding:0 1rem;color:#17211b}pre{white-space:pre-wrap}</style></head><body>'
    + '<h1>' + esc(rec.title) + '</h1><p>' + esc(rec.date) + '</p>' + body + todos
    + '<p>Shared note. The transcript and the audio are not on this page.</p></body></html>';
}
module.exports = { fileOf, publish, readPublic, revoke, noteOf, html };
