'use strict';
// Optional notes. The transcript stays on this Mac until the user has saved a summary key and asks for notes.
const HOSTS = {
  'api.fireworks.ai': { base: 'https://api.fireworks.ai/inference/v1', model: 'accounts/fireworks/models/gpt-oss-120b' },
  'api.openai.com': { base: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
  'api.groq.com': { base: 'https://api.groq.com/openai/v1', model: 'llama-3.3-70b-versatile' },
  'api.together.xyz': { base: 'https://api.together.xyz/v1', model: 'meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo' },
  'api.together.ai': { base: 'https://api.together.ai/v1', model: 'meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo' },
};
const SYSTEM = 'You write meeting notes from a transcript. Return one JSON object with keys summary and todos. summary is plain sentences. todos is one action per line. Use only what the transcript says.';

function parseNotes(text) {
  const raw = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  const slice = start >= 0 && end > start ? raw.slice(start, end + 1) : raw;
  const parsed = JSON.parse(slice);
  return {
    summary: String(parsed.summary || '').slice(0, 20000),
    todos: String(parsed.todos || '').slice(0, 8000),
  };
}

async function summarize({ host, key, transcript, fetchImpl }) {
  if (!String(transcript || '').trim()) {
    throw Object.assign(new Error('Record the meeting before writing notes.'), { status: 400 });
  }
  if (!String(key || '').trim()) {
    throw Object.assign(new Error('Add a summary key in Settings. Recording already works without it.'), { status: 400 });
  }
  const spec = HOSTS[host];
  if (!spec) throw Object.assign(new Error('That summary host is not available in this build.'), { status: 400 });
  const send = fetchImpl || fetch;
  const res = await send(spec.base + '/chat/completions', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: spec.model,
      temperature: 0.2,
      messages: [
        { role: 'system', content: SYSTEM },
        { role: 'user', content: String(transcript).slice(0, 60000) },
      ],
    }),
  });
  const data = await res.json();
  const text = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  if (!text) {
    const reason = data && data.error && (data.error.message || data.error.code) || 'empty';
    throw Object.assign(new Error('The summary host did not return notes. ' + String(reason).slice(0, 160)), { status: 502 });
  }
  try { return parseNotes(text); }
  catch (e) { throw Object.assign(new Error('The summary host did not return notes.'), { status: 502 }); }
}

module.exports = { HOSTS, summarize, parseNotes };
