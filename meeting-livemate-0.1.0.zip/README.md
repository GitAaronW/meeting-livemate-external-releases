# Meeting LiveMate

This package records a meeting on the Mac, transcribes speech, and keeps the notes on that Mac.

It listens through the microphone. It does not capture system audio. The daily beta is a different, fuller app. This package does not include Feishu, automatic Notion, voiceprints, saved audio, or internal workplace tools.

## Install

Double-click `install.command`. It copies the app into `~/Library/Application Support/MeetingLiveMate` and opens it. It does not write into the daily beta folders.

The first time macOS may ask you to open the file from the Finder shortcut menu. This build is not notarized.

## Upgrade

In the app, choose Check for updates. A newer version is downloaded from `GitAaronW/meeting-livemate-external-releases` and replaces the installed program. Notes already on the Mac stay. This package does not update from the older public trial feed.

## Keys

A transcription key is entered in Settings on that Mac. A summary key is optional. Neither key is in this repository.

Share copies a link that opens on that Mac. The page shows the summary and the action items. It does not show the transcript or the audio.
